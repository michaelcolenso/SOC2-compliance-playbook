# Agentic Repository Setup Guide

Complete guide for setting up and running the SOC 2 Playbook multi-agent workflow system.

---

## Repository Structure

```
agentic-repo/
├── README.md                    # Main documentation
├── AGENTIC_REPO_GUIDE.md        # This file
├── requirements.txt             # Python dependencies
├── Makefile                     # Convenience commands
├── Dockerfile                   # Container definition
├── docker-compose.yml           # Multi-service orchestration
├── .env.example                 # Environment template
├── .gitignore                   # Git ignore rules
│
├── workflows/                   # Workflow definitions
│   └── soc2_playbook.json       # Main workflow config
│
├── agents/                      # Agent prompt definitions
│   ├── phase1_research/         # Research agents
│   ├── phase2_structure/        # Structure agents
│   ├── phase3_content/          # Content agents
│   ├── phase4_validation/       # Validation agents
│   └── phase5_launch/           # Launch agents
│
├── src/                         # Source code
│   ├── orchestrator/            # Core orchestration engine
│   │   ├── engine.py            # Main orchestrator
│   │   ├── state_manager.py     # State persistence
│   │   ├── agent_runner.py      # Agent execution
│   │   ├── quality_gates.py     # Quality validation
│   │   └── __main__.py          # CLI entry point
│   └── monitor/                 # Monitoring & reporting
│       └── reporter.py          # Progress reports
│
├── tests/                       # Test suite
│   └── test_orchestrator.py
│
├── data/                        # Workflow state (gitignored)
├── outputs/                     # Agent outputs (gitignored)
├── logs/                        # Execution logs (gitignored)
├── reports/                     # Generated reports (gitignored)
│
├── templates/                   # Template storage
│   ├── designs/                 # Template designs
│   └── generated/               # Generated templates
│
├── tools/                       # AI-powered tools
│   ├── readiness_scorecard/     # Web app
│   ├── policy_generator/        # Web app
│   ├── auditor_matcher/         # Web app
│   ├── evidence_tracker/        # Airtable/Notion
│   └── chatbot/                 # Discord/Widget bot
│
├── visuals/                     # Visual assets
│   ├── flowcharts/
│   ├── infographics/
│   ├── checklists/
│   └── branding/
│
├── case_studies/                # Founder case studies
├── marketing/                   # Marketing materials
├── launch/                      # Launch plans
├── review/                      # Review outputs
└── feedback/                    # Beta feedback
```

---

## Quick Start (5 minutes)

### 1. Clone and Setup

```bash
git clone <repo-url>
cd agentic-repo

# Install dependencies
pip install -r requirements.txt

# Copy environment template
cp .env.example .env
# Edit .env with your API keys
```

### 2. Configure Environment

Edit `.env`:

```bash
# Required
OPENAI_API_KEY=sk-your-key-here
ANTHROPIC_API_KEY=sk-your-key-here

# Optional (defaults work fine)
STATE_DB_URL=sqlite:///data/workflow.db
OUTPUT_DIR=./outputs
LOG_LEVEL=INFO
```

### 3. Initialize and Run

```bash
# Initialize workflow state
make init

# Check status
make status

# Run Phase 1 agents
make phase N=1

# Or run everything
make run-all
```

---

## Architecture Overview

### Orchestration Engine

The orchestration engine (`src/orchestrator/engine.py`) coordinates all agents:

1. **State Management**: SQLite database tracks all agent states
2. **Dependency Resolution**: Agents wait for dependencies to complete
3. **Parallel Execution**: Parallelizable agents run simultaneously
4. **Quality Gates**: Automated validation at each phase
5. **Error Handling**: Automatic retries with exponential backoff

### Agent Execution Flow

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   PENDING   │────▶│   RUNNING    │────▶│  COMPLETED  │
└─────────────┘     └──────────────┘     └─────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │    FAILED    │────▶ Retry (3x)
                    └──────────────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   BLOCKED    │ (dependency not met)
                    └──────────────┘
```

### State Database Schema

```sql
-- workflow_state: Full workflow state (JSON)
-- agent_executions: Individual agent status
-- artifacts: Generated files
-- quality_gates: Gate status
```

---

## Commands Reference

### Workflow Commands

| Command | Description |
|---------|-------------|
| `make init` | Initialize workflow state |
| `make status` | Check current status |
| `make phase N=1` | Run Phase N agents |
| `make agent A=1.1` | Run specific agent |
| `make retry A=1.1` | Retry failed agent |
| `make gate G=1.1` | Check quality gate |
| `make run-all` | Run complete workflow |
| `make report` | Generate progress report |

### Docker Commands

| Command | Description |
|---------|-------------|
| `make docker-build` | Build Docker image |
| `make docker-up` | Start services |
| `make docker-down` | Stop services |
| `make docker-logs` | View logs |

### Development Commands

| Command | Description |
|---------|-------------|
| `make test` | Run tests |
| `make lint` | Run linter |
| `make format` | Format code |
| `make clean` | Clean outputs |

---

## Workflow Configuration

The workflow is defined in `workflows/soc2_playbook.json`:

```json
{
  "workflow_id": "soc2-playbook-v1",
  "agents": [
    {
      "agent_id": "1.1",
      "name": "Market Research Synthesizer",
      "phase": 1,
      "prompt_file": "phase1_research/market_research.md",
      "inputs": [],
      "outputs": ["research/cost_analysis.json"],
      "dependencies": [],
      "parallelizable": false,
      "timeout": 7200,
      "retries": 2
    }
  ],
  "quality_gates": {
    "1.1": {
      "type": "data_points",
      "file": "research/cost_analysis.json",
      "min_count": 20
    }
  }
}
```

### Agent Configuration Fields

| Field | Description |
|-------|-------------|
| `agent_id` | Unique identifier (e.g., "1.1", "3.1a") |
| `name` | Human-readable name |
| `phase` | Phase number (1-5) |
| `prompt_file` | Path to agent prompt |
| `inputs` | Files the agent reads |
| `outputs` | Files the agent creates |
| `dependencies` | Agents that must complete first |
| `parallelizable` | Can run in parallel with same-phase agents |
| `timeout` | Max execution time (seconds) |
| `retries` | Number of retry attempts |

### Quality Gate Types

| Type | Description | Parameters |
|------|-------------|------------|
| `file_count` | Check files exist | `files`, `min_count` |
| `data_points` | Check JSON array length | `file`, `field`, `min_count` |
| `interviews` | Check interview files | `min_count` |
| `page_count` | Check document length | `chapters_dir`, `min_pages` |
| `beta_feedback` | Check feedback scores | `min_rating`, `min_responses` |
| `custom` | Custom validation | `check_function` |

---

## Agent Prompt Structure

Agent prompts are in `agents/[phase]/[agent_name].md`:

```markdown
# AGENT X.X: [Name]

## Role
[What the agent does]

## Objective
[What the agent should accomplish]

## Inputs
[Expected input files]

## Outputs
[Expected output files with structure]

## Quality Criteria
[How to verify success]
```

---

## Monitoring & Reporting

### Progress Report

```bash
# Generate HTML report
make report

# Or programmatically
python -m src.monitor.report --format html --output reports/status.html
```

### Report Formats

- **JSON**: Machine-readable for automation
- **HTML**: Visual dashboard with progress bars
- **Markdown**: GitHub-compatible for documentation

### Metrics Tracked

- Overall progress percentage
- Agents by status (completed, running, pending, failed, blocked)
- Quality gates passed/failed
- Artifacts generated
- Time elapsed

---

## Docker Deployment

### Basic Usage

```bash
# Build image
docker-compose build

# Run orchestrator
docker-compose up orchestrator

# Run with monitoring
docker-compose --profile monitoring up

# Run with PostgreSQL (production)
docker-compose --profile production up
```

### Services

| Service | Purpose | Port |
|---------|---------|------|
| orchestrator | Main agent runner | - |
| redis | Distributed state (optional) | 6379 |
| postgres | Production database (optional) | 5432 |
| prometheus | Metrics collection | 9090 |
| grafana | Dashboards | 3000 |

---

## Extending the System

### Adding a New Agent

1. Create prompt file: `agents/phaseX/[agent_name].md`
2. Add to workflow config:
   ```json
   {
     "agent_id": "3.5",
     "name": "New Agent",
     "phase": 3,
     "prompt_file": "phase3_content/new_agent.md",
     "inputs": ["input1.json"],
     "outputs": ["output1.md"],
     "dependencies": ["3.1"],
     "parallelizable": true
   }
   ```
3. Add quality gate:
   ```json
   "3.5": {
     "type": "file_count",
     "files": ["output1.md"],
     "min_count": 1
   }
   ```

### Adding a New Quality Gate Type

1. Edit `src/orchestrator/quality_gates.py`
2. Add handler method:
   ```python
   async def _check_my_gate(self, gate_id, criteria, state):
       # Validation logic
       return {"status": "passed"}
   ```
3. Add to `check()` method dispatch

---

## Troubleshooting

### Common Issues

**Agent fails repeatedly**
```bash
# Check logs
make docker-logs

# Retry with more context
make retry A=1.1
```

**Quality gate fails**
```bash
# Check specific gate
make gate G=1.1

# View gate details in state
python -c "import json; print(json.dumps(json.load(open('data/workflow.db')), indent=2))"
```

**State corruption**
```bash
# Reset workflow
make clean
make init
```

### Debug Mode

```bash
# Enable debug logging
LOG_LEVEL=DEBUG make phase N=1

# Or in .env
DEBUG=true
```

---

## Production Considerations

### Scaling

- Use Redis for distributed state
- Run agents on multiple workers
- Use PostgreSQL for concurrent access

### Security

- Store API keys in secrets manager
- Use encrypted database connections
- Restrict file system access

### Monitoring

- Enable Prometheus metrics
- Set up Sentry for error tracking
- Configure Slack notifications

### Backup

```bash
# Backup state
cp data/workflow.db backups/workflow_$(date +%Y%m%d).db

# Backup outputs
tar -czf backups/outputs_$(date +%Y%m%d).tar.gz outputs/
```

---

## Development

### Running Tests

```bash
# All tests
make test

# Specific test
pytest tests/test_orchestrator.py::test_state_manager_init -v

# With coverage
pytest --cov=src --cov-report=html
```

### Code Style

```bash
# Format code
make format

# Check style
make lint
```

---

## API Reference

### OrchestratorEngine

```python
from src.orchestrator import OrchestratorEngine, WorkflowConfig

# Initialize
config = WorkflowConfig.parse_file("workflows/soc2_playbook.json")
engine = OrchestratorEngine(config, state_manager)

# Run workflow
await engine.initialize_workflow()
await engine.run_phase(1)

# Check status
status = await engine.get_status()
```

### StateManager

```python
from src.orchestrator import StateManager

sm = StateManager("data/workflow.db")

# Save state
await sm.save_state({"key": "value"})

# Get state
state = await sm.get_full_state()

# Update agent
await sm.update_agent_status("1.1", "completed")
```

---

## Resources

- [Workflow JSON Schema](workflows/soc2_playbook.json)
- [Agent Prompt Examples](agents/phase1_research/)
- [Test Suite](tests/)
- [Docker Compose](docker-compose.yml)

---

## License

MIT
